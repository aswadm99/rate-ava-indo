# Roblox OAuth 2.0 — GitHub Pages

Starter frontend statis untuk Roblox OAuth 2.0 Authorization Code + PKCE.

## Deploy
1. Buat repository GitHub bernama `username.github.io` (atau aktifkan Pages untuk repo lain).
2. Upload `index.html`.
3. Di Settings → Pages, aktifkan deploy dari branch `main` / root.
4. Buka URL Pages kamu.
5. Buat OAuth app di Roblox Creator Dashboard.
6. Daftarkan Redirect URL yang persis sama dengan URL Pages yang membuka `index.html`.
   Contoh root: `https://username.github.io/`
   Contoh repo: `https://username.github.io/nama-repo/`
7. Masukkan Client ID ke halaman lalu login.

## Catatan penting
- Jangan pernah menaruh Client Secret di HTML/JavaScript.
- Ini contoh browser-only PKCE untuk login dan membaca userinfo.
- Jika endpoint token Roblox tidak mengizinkan CORS dari GitHub Pages atau kamu perlu menyimpan token secara aman, gunakan backend serverless (misalnya Cloudflare Worker) dan simpan rahasia hanya di server.
- OAuth Roblox beta dan endpoint/scopes dapat berubah; cek dokumentasi resmi: https://create.roblox.com/docs/cloud/auth/oauth2-reference
